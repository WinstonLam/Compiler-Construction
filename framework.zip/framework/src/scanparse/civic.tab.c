/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "src/scanparse/civic.y"

#define YYDEBUG 1

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <memory.h>
#include "types.h"
#include "tree_basic.h"
#include "str.h"
#include "dbug.h"
#include "ctinfo.h"
#include "free.h"
#include "globals.h"

static node *parseresult = NULL;
extern int yylex();
static int yyerror( char *errname);


#line 92 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    BRACKET_L = 258,               /* BRACKET_L  */
    BRACKET_R = 259,               /* BRACKET_R  */
    COMMA = 260,                   /* COMMA  */
    SEMICOLON = 261,               /* SEMICOLON  */
    BRACES_L = 262,                /* BRACES_L  */
    BRACES_R = 263,                /* BRACES_R  */
    MINUS = 264,                   /* MINUS  */
    PLUS = 265,                    /* PLUS  */
    STAR = 266,                    /* STAR  */
    SLASH = 267,                   /* SLASH  */
    PERCENT = 268,                 /* PERCENT  */
    LE = 269,                      /* LE  */
    LT = 270,                      /* LT  */
    GE = 271,                      /* GE  */
    GT = 272,                      /* GT  */
    EQ = 273,                      /* EQ  */
    NE = 274,                      /* NE  */
    OR = 275,                      /* OR  */
    AND = 276,                     /* AND  */
    TRUEVAL = 277,                 /* TRUEVAL  */
    FALSEVAL = 278,                /* FALSEVAL  */
    LET = 279,                     /* LET  */
    EXTERN = 280,                  /* EXTERN  */
    TYPE_BOOL = 281,               /* TYPE_BOOL  */
    TYPE_INT = 282,                /* TYPE_INT  */
    TYPE_FLOAT = 283,              /* TYPE_FLOAT  */
    TYPE_VOID = 284,               /* TYPE_VOID  */
    FACTORIAL = 285,               /* FACTORIAL  */
    EXPORT = 286,                  /* EXPORT  */
    WHILE = 287,                   /* WHILE  */
    FOR = 288,                     /* FOR  */
    IF = 289,                      /* IF  */
    RETURN = 290,                  /* RETURN  */
    ELSE = 291,                    /* ELSE  */
    DO = 292,                      /* DO  */
    NUM = 293,                     /* NUM  */
    FLOAT = 294,                   /* FLOAT  */
    ID = 295,                      /* ID  */
    UMINUS = 296,                  /* UMINUS  */
    THEN = 297,                    /* THEN  */
    CAST = 298                     /* CAST  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define BRACKET_L 258
#define BRACKET_R 259
#define COMMA 260
#define SEMICOLON 261
#define BRACES_L 262
#define BRACES_R 263
#define MINUS 264
#define PLUS 265
#define STAR 266
#define SLASH 267
#define PERCENT 268
#define LE 269
#define LT 270
#define GE 271
#define GT 272
#define EQ 273
#define NE 274
#define OR 275
#define AND 276
#define TRUEVAL 277
#define FALSEVAL 278
#define LET 279
#define EXTERN 280
#define TYPE_BOOL 281
#define TYPE_INT 282
#define TYPE_FLOAT 283
#define TYPE_VOID 284
#define FACTORIAL 285
#define EXPORT 286
#define WHILE 287
#define FOR 288
#define IF 289
#define RETURN 290
#define ELSE 291
#define DO 292
#define NUM 293
#define FLOAT 294
#define ID 295
#define UMINUS 296
#define THEN 297
#define CAST 298

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 22 "src/scanparse/civic.y"

 nodetype            nodetype;
 char               *id;
 int                 cint;
 float               cflt;
 binop               cbinop;
 monop               cmonop;
 type                ctype;
 node               *node;

#line 242 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_BRACKET_L = 3,                  /* BRACKET_L  */
  YYSYMBOL_BRACKET_R = 4,                  /* BRACKET_R  */
  YYSYMBOL_COMMA = 5,                      /* COMMA  */
  YYSYMBOL_SEMICOLON = 6,                  /* SEMICOLON  */
  YYSYMBOL_BRACES_L = 7,                   /* BRACES_L  */
  YYSYMBOL_BRACES_R = 8,                   /* BRACES_R  */
  YYSYMBOL_MINUS = 9,                      /* MINUS  */
  YYSYMBOL_PLUS = 10,                      /* PLUS  */
  YYSYMBOL_STAR = 11,                      /* STAR  */
  YYSYMBOL_SLASH = 12,                     /* SLASH  */
  YYSYMBOL_PERCENT = 13,                   /* PERCENT  */
  YYSYMBOL_LE = 14,                        /* LE  */
  YYSYMBOL_LT = 15,                        /* LT  */
  YYSYMBOL_GE = 16,                        /* GE  */
  YYSYMBOL_GT = 17,                        /* GT  */
  YYSYMBOL_EQ = 18,                        /* EQ  */
  YYSYMBOL_NE = 19,                        /* NE  */
  YYSYMBOL_OR = 20,                        /* OR  */
  YYSYMBOL_AND = 21,                       /* AND  */
  YYSYMBOL_TRUEVAL = 22,                   /* TRUEVAL  */
  YYSYMBOL_FALSEVAL = 23,                  /* FALSEVAL  */
  YYSYMBOL_LET = 24,                       /* LET  */
  YYSYMBOL_EXTERN = 25,                    /* EXTERN  */
  YYSYMBOL_TYPE_BOOL = 26,                 /* TYPE_BOOL  */
  YYSYMBOL_TYPE_INT = 27,                  /* TYPE_INT  */
  YYSYMBOL_TYPE_FLOAT = 28,                /* TYPE_FLOAT  */
  YYSYMBOL_TYPE_VOID = 29,                 /* TYPE_VOID  */
  YYSYMBOL_FACTORIAL = 30,                 /* FACTORIAL  */
  YYSYMBOL_EXPORT = 31,                    /* EXPORT  */
  YYSYMBOL_WHILE = 32,                     /* WHILE  */
  YYSYMBOL_FOR = 33,                       /* FOR  */
  YYSYMBOL_IF = 34,                        /* IF  */
  YYSYMBOL_RETURN = 35,                    /* RETURN  */
  YYSYMBOL_ELSE = 36,                      /* ELSE  */
  YYSYMBOL_DO = 37,                        /* DO  */
  YYSYMBOL_NUM = 38,                       /* NUM  */
  YYSYMBOL_FLOAT = 39,                     /* FLOAT  */
  YYSYMBOL_ID = 40,                        /* ID  */
  YYSYMBOL_UMINUS = 41,                    /* UMINUS  */
  YYSYMBOL_THEN = 42,                      /* THEN  */
  YYSYMBOL_CAST = 43,                      /* CAST  */
  YYSYMBOL_YYACCEPT = 44,                  /* $accept  */
  YYSYMBOL_program = 45,                   /* program  */
  YYSYMBOL_declarations = 46,              /* declarations  */
  YYSYMBOL_declaration = 47,               /* declaration  */
  YYSYMBOL_globdecl = 48,                  /* globdecl  */
  YYSYMBOL_fundef = 49,                    /* fundef  */
  YYSYMBOL_vardecl = 50,                   /* vardecl  */
  YYSYMBOL_funbody = 51,                   /* funbody  */
  YYSYMBOL_param = 52,                     /* param  */
  YYSYMBOL_globdef = 53,                   /* globdef  */
  YYSYMBOL_exprs = 54,                     /* exprs  */
  YYSYMBOL_expr = 55,                      /* expr  */
  YYSYMBOL_binop = 56,                     /* binop  */
  YYSYMBOL_monop = 57,                     /* monop  */
  YYSYMBOL_funcall = 58,                   /* funcall  */
  YYSYMBOL_block = 59,                     /* block  */
  YYSYMBOL_stmts = 60,                     /* stmts  */
  YYSYMBOL_stmt = 61,                      /* stmt  */
  YYSYMBOL_exprstmt = 62,                  /* exprstmt  */
  YYSYMBOL_assign = 63,                    /* assign  */
  YYSYMBOL_ifelse = 64,                    /* ifelse  */
  YYSYMBOL_while = 65,                     /* while  */
  YYSYMBOL_dowhile = 66,                   /* dowhile  */
  YYSYMBOL_for = 67,                       /* for  */
  YYSYMBOL_return = 68,                    /* return  */
  YYSYMBOL_varlet = 69,                    /* varlet  */
  YYSYMBOL_floatval = 70,                  /* floatval  */
  YYSYMBOL_intval = 71,                    /* intval  */
  YYSYMBOL_boolval = 72,                   /* boolval  */
  YYSYMBOL_type = 73,                      /* type  */
  YYSYMBOL_constant = 74                   /* constant  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  16
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   551

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  44
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  31
/* YYNRULES -- Number of rules.  */
#define YYNRULES  88
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  184

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   298


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    78,    78,    84,    88,    94,    98,   102,   108,   114,
     119,   124,   128,   132,   137,   144,   148,   152,   156,   162,
     166,   170,   175,   180,   184,   190,   195,   200,   204,   210,
     214,   220,   224,   228,   232,   236,   240,   244,   250,   254,
     258,   262,   266,   270,   274,   278,   282,   286,   290,   294,
     298,   304,   308,   314,   318,   324,   328,   332,   338,   342,
     348,   352,   356,   360,   364,   368,   372,   378,   384,   390,
     394,   400,   406,   412,   416,   422,   426,   432,   438,   444,
     450,   454,   460,   464,   468,   472,   478,   482,   486
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "BRACKET_L",
  "BRACKET_R", "COMMA", "SEMICOLON", "BRACES_L", "BRACES_R", "MINUS",
  "PLUS", "STAR", "SLASH", "PERCENT", "LE", "LT", "GE", "GT", "EQ", "NE",
  "OR", "AND", "TRUEVAL", "FALSEVAL", "LET", "EXTERN", "TYPE_BOOL",
  "TYPE_INT", "TYPE_FLOAT", "TYPE_VOID", "FACTORIAL", "EXPORT", "WHILE",
  "FOR", "IF", "RETURN", "ELSE", "DO", "NUM", "FLOAT", "ID", "UMINUS",
  "THEN", "CAST", "$accept", "program", "declarations", "declaration",
  "globdecl", "fundef", "vardecl", "funbody", "param", "globdef", "exprs",
  "expr", "binop", "monop", "funcall", "block", "stmts", "stmt",
  "exprstmt", "assign", "ifelse", "while", "dowhile", "for", "return",
  "varlet", "floatval", "intval", "boolval", "type", "constant", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-91)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-78)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      39,    -7,   -91,   -91,   -91,   -91,    -7,    25,   -91,    39,
     -91,   -91,   -91,   -11,    -9,    -8,   -91,   -91,    11,    21,
      12,    29,   -91,   252,    57,   -91,    65,   -91,   252,    56,
      68,    33,   202,   252,   -91,   -91,   252,   -91,   -91,    72,
     441,   -91,   -91,   -91,   -91,   -91,   -91,   -91,    71,    74,
      75,    83,   457,    87,    82,    92,   319,    94,   -91,   -91,
     230,   -91,   252,   252,   252,   252,   252,   252,   252,   252,
     252,   252,   252,   252,   252,   -91,   105,    87,   116,   -91,
      98,   128,   130,   241,   125,    35,   180,   121,   473,   -91,
     180,   -91,   -91,   -91,   -91,   -91,   -91,   -91,   115,   100,
      87,    -7,   -91,   252,   -91,   137,   408,   124,   124,   -91,
     -91,   -91,    95,    95,    95,    95,   159,   534,   159,   159,
     -91,   134,    87,   252,   117,   252,   -91,   489,   158,   113,
     -91,   -91,   -91,   -91,   -91,   252,    47,   138,   -91,   -91,
     -91,   252,   -91,   141,   337,   110,   355,   -91,   -91,   144,
     150,   505,    -7,   252,   -91,   -91,   -91,   125,   155,   125,
     -91,   252,   -91,   -91,   521,   -91,   252,   118,   373,    -7,
     425,   125,   176,   -91,   252,   -91,   -91,   301,   125,   252,
     -91,   391,   125,   -91
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,    82,    83,    84,    85,     0,     0,     2,     4,
       5,     6,     7,     0,     0,     0,     1,     3,     0,     0,
       0,     0,    28,     0,     0,     8,     0,    26,     0,     0,
       0,     0,     0,     0,    80,    81,     0,    79,    78,    37,
       0,    33,    34,    36,    88,    86,    87,    31,     0,     0,
       0,     0,     0,    22,     0,    23,     0,     0,    52,    51,
       0,    27,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    14,     0,    22,     0,    25,
       0,     0,     0,     0,     0,    37,    20,     0,     0,    21,
      59,    60,    61,    62,    63,    64,    65,    66,     0,     0,
      22,     0,    32,     0,    53,     0,    30,    39,    38,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      13,     0,    22,     0,     0,     0,    76,     0,     0,     0,
      57,    19,    12,    67,    58,     0,     0,     0,    24,    35,
      54,     0,    10,     0,     0,     0,     0,    75,    56,     0,
       0,     0,    17,     0,    11,    29,     9,     0,     0,     0,
      55,     0,    68,    18,     0,    71,     0,    70,     0,    16,
       0,     0,     0,    15,     0,    69,    72,     0,     0,     0,
      73,     0,     0,    74
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -91,   -91,   175,   -91,   -91,   -91,   -90,   -70,   -20,   -91,
      44,   -23,   -91,   -91,   -91,   126,   -74,   -83,   -91,   -91,
     -91,   -91,   -91,   -91,   -91,   -91,   -91,   -91,   -91,     2,
     -91
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     7,     8,     9,    10,    11,    86,    87,    30,    12,
     105,    88,    41,    42,    43,   129,    89,    90,    91,    92,
      93,    94,    95,    96,    97,    98,    44,    45,    46,    99,
      47
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      40,   130,    13,    14,    49,    52,    51,   121,    15,    56,
      58,    13,   131,    59,    21,    26,   134,    22,    27,     2,
       3,     4,     5,    31,    24,    16,    31,    25,    31,    18,
     137,    19,    20,    29,    57,    23,    28,   106,    60,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   143,   152,   149,     2,     3,     4,     5,   -77,
     127,    48,   163,    53,     1,     2,     3,     4,     5,    50,
       6,   153,    54,    55,   130,    60,   130,    75,    76,   173,
     139,   138,    77,     2,     3,     4,     5,    78,   130,   100,
      32,     2,     3,     4,     5,   130,    33,   101,   103,   130,
     144,   123,   146,    31,    62,    63,    64,    65,    66,    34,
      35,   120,   151,     2,     3,     4,     5,    36,   106,    80,
      81,    82,    83,   122,    84,    37,    38,    85,    32,   132,
     164,   124,   128,   125,    33,    64,    65,    66,   168,   135,
     136,   140,   142,   170,   145,   150,   154,    34,    35,   156,
     158,   177,   160,   161,   171,    36,   181,    80,    81,    82,
      83,    32,    84,    37,    38,    85,   148,    33,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,   166,
      34,    35,   176,    32,    17,   155,     0,     0,    36,    33,
      80,    81,    82,    83,     0,    84,    37,    38,    85,     0,
       0,     0,    34,    35,     0,    32,     0,     0,     0,     0,
      36,    33,    80,    81,    82,    83,     0,    84,    37,    38,
      85,     0,     0,     0,    34,    35,     0,     0,     2,     3,
       4,     5,    36,    32,   104,     0,     0,     0,     0,    33,
      37,    38,    39,     0,    32,     0,     0,   126,     0,     0,
      33,     0,    34,    35,     0,    32,     0,     0,     0,     0,
      36,    33,     0,    34,    35,     0,     0,     0,    37,    38,
      39,    36,     0,     0,    34,    35,     0,     0,     0,    37,
      38,    39,    36,   165,     0,   167,     0,     0,     0,     0,
      37,    38,    39,     0,     0,     0,     0,   175,     0,     0,
       0,     0,     0,     0,   180,   178,   179,     0,   183,     0,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,   102,     0,     0,     0,     0,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,   157,     0,     0,     0,     0,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,   159,
       0,     0,     0,     0,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,   172,     0,     0,
       0,     0,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,   182,     0,     0,     0,     0,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,   141,     0,     0,     0,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
     174,     0,     0,     0,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    61,     0,     0,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    79,     0,     0,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,   133,
       0,     0,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,   147,     0,     0,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,   162,     0,     0,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,   169,     0,     0,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    62,    63,    64,    65,    66,    67,    68,
      69,    70
};

static const yytype_int16 yycheck[] =
{
      23,    84,     0,     1,    24,    28,    26,    77,     6,    32,
      33,     9,    86,    36,     3,     3,    90,     6,     6,    26,
      27,    28,    29,    21,     3,     0,    24,     6,    26,    40,
     100,    40,    40,     4,    32,    24,    24,    60,     3,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,   122,     6,   128,    26,    27,    28,    29,    24,
      83,     4,   152,     7,    25,    26,    27,    28,    29,     4,
      31,    24,     4,    40,   157,     3,   159,     6,     4,   169,
     103,   101,     7,    26,    27,    28,    29,     4,   171,     7,
       3,    26,    27,    28,    29,   178,     9,     5,     4,   182,
     123,     3,   125,   101,     9,    10,    11,    12,    13,    22,
      23,     6,   135,    26,    27,    28,    29,    30,   141,    32,
      33,    34,    35,     7,    37,    38,    39,    40,     3,     8,
     153,     3,     7,     3,     9,    11,    12,    13,   161,    24,
      40,     4,     8,   166,    27,    32,     8,    22,    23,     8,
      40,   174,     8,     3,    36,    30,   179,    32,    33,    34,
      35,     3,    37,    38,    39,    40,     8,     9,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    24,
      22,    23,     6,     3,     9,   141,    -1,    -1,    30,     9,
      32,    33,    34,    35,    -1,    37,    38,    39,    40,    -1,
      -1,    -1,    22,    23,    -1,     3,    -1,    -1,    -1,    -1,
      30,     9,    32,    33,    34,    35,    -1,    37,    38,    39,
      40,    -1,    -1,    -1,    22,    23,    -1,    -1,    26,    27,
      28,    29,    30,     3,     4,    -1,    -1,    -1,    -1,     9,
      38,    39,    40,    -1,     3,    -1,    -1,     6,    -1,    -1,
       9,    -1,    22,    23,    -1,     3,    -1,    -1,    -1,    -1,
      30,     9,    -1,    22,    23,    -1,    -1,    -1,    38,    39,
      40,    30,    -1,    -1,    22,    23,    -1,    -1,    -1,    38,
      39,    40,    30,   157,    -1,   159,    -1,    -1,    -1,    -1,
      38,    39,    40,    -1,    -1,    -1,    -1,   171,    -1,    -1,
      -1,    -1,    -1,    -1,   178,     4,     5,    -1,   182,    -1,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,     4,    -1,    -1,    -1,    -1,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,     4,    -1,    -1,    -1,    -1,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,     4,
      -1,    -1,    -1,    -1,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,     4,    -1,    -1,
      -1,    -1,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,     4,    -1,    -1,    -1,    -1,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,     5,    -1,    -1,    -1,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
       5,    -1,    -1,    -1,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,     6,    -1,    -1,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,     6,    -1,    -1,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,     6,
      -1,    -1,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,     6,    -1,    -1,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,     6,    -1,    -1,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,     6,    -1,    -1,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,     9,    10,    11,    12,    13,    14,    15,
      16,    17
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    25,    26,    27,    28,    29,    31,    45,    46,    47,
      48,    49,    53,    73,    73,    73,     0,    46,    40,    40,
      40,     3,     6,    24,     3,     6,     3,     6,    24,     4,
      52,    73,     3,     9,    22,    23,    30,    38,    39,    40,
      55,    56,    57,    58,    70,    71,    72,    74,     4,    52,
       4,    52,    55,     7,     4,    40,    55,    73,    55,    55,
       3,     6,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,     6,     4,     7,     4,     6,
      32,    33,    34,    35,    37,    40,    50,    51,    55,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    73,
       7,     5,     4,     4,     4,    54,    55,    55,    55,    55,
      55,    55,    55,    55,    55,    55,    55,    55,    55,    55,
       6,    51,     7,     3,     3,     3,     6,    55,     7,    59,
      61,    60,     8,     6,    60,    24,    40,    51,    52,    55,
       4,     5,     8,    51,    55,    27,    55,     6,     8,    60,
      32,    55,     6,    24,     8,    54,     8,     4,    40,     4,
       8,     3,     6,    50,    55,    59,    24,    59,    55,     6,
      55,    36,     4,    50,     5,    59,     6,    55,     4,     5,
      59,    55,     4,    59
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    44,    45,    46,    46,    47,    47,    47,    48,    49,
      49,    49,    49,    49,    49,    50,    50,    50,    50,    51,
      51,    51,    51,    52,    52,    53,    53,    53,    53,    54,
      54,    55,    55,    55,    55,    55,    55,    55,    56,    56,
      56,    56,    56,    56,    56,    56,    56,    56,    56,    56,
      56,    57,    57,    58,    58,    59,    59,    59,    60,    60,
      61,    61,    61,    61,    61,    61,    61,    62,    63,    64,
      64,    65,    66,    67,    67,    68,    68,    69,    70,    71,
      72,    72,    73,    73,    73,    73,    74,    74,    74
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     2,     1,     1,     1,     1,     4,     9,
       8,     8,     7,     7,     6,     6,     5,     3,     4,     2,
       1,     1,     0,     2,     4,     6,     4,     5,     3,     3,
       1,     1,     3,     1,     1,     4,     1,     1,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     2,     2,     3,     4,     3,     2,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     4,     7,
       5,     5,     7,    10,    12,     3,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* program: declarations  */
#line 79 "src/scanparse/civic.y"
      {
        parseresult = TBmakeProgram(NULL, (yyvsp[0].node));
      }
#line 1490 "y.tab.c"
    break;

  case 3: /* declarations: declaration declarations  */
#line 85 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeDecls((yyvsp[-1].node), (yyvsp[0].node));
      }
#line 1498 "y.tab.c"
    break;

  case 4: /* declarations: declaration  */
#line 89 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeDecls((yyvsp[0].node), NULL);
      }
#line 1506 "y.tab.c"
    break;

  case 5: /* declaration: globdecl  */
#line 95 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1514 "y.tab.c"
    break;

  case 6: /* declaration: fundef  */
#line 99 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1522 "y.tab.c"
    break;

  case 7: /* declaration: globdef  */
#line 103 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1530 "y.tab.c"
    break;

  case 8: /* globdecl: EXTERN type ID SEMICOLON  */
#line 109 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeGlobdecl( (yyvsp[-2].ctype), STRcpy((yyvsp[-1].id)), NULL);
      }
#line 1538 "y.tab.c"
    break;

  case 9: /* fundef: EXPORT type ID BRACKET_L param BRACKET_R BRACES_L funbody BRACES_R  */
#line 115 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFundef((yyvsp[-7].ctype), STRcpy((yyvsp[-6].id)), NULL, (yyvsp[-1].node), (yyvsp[-4].node));
        FUNDEF_ISEXPORT((yyval.node)) = 1;
      }
#line 1547 "y.tab.c"
    break;

  case 10: /* fundef: EXPORT type ID BRACKET_L BRACKET_R BRACES_L funbody BRACES_R  */
#line 120 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFundef((yyvsp[-6].ctype), STRcpy((yyvsp[-5].id)), NULL, (yyvsp[-1].node), NULL);
        FUNDEF_ISEXPORT((yyval.node)) = 1;
      }
#line 1556 "y.tab.c"
    break;

  case 11: /* fundef: type ID BRACKET_L param BRACKET_R BRACES_L funbody BRACES_R  */
#line 125 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFundef((yyvsp[-7].ctype), STRcpy((yyvsp[-6].id)), NULL, (yyvsp[-1].node), (yyvsp[-4].node));
      }
#line 1564 "y.tab.c"
    break;

  case 12: /* fundef: type ID BRACKET_L BRACKET_R BRACES_L funbody BRACES_R  */
#line 129 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFundef((yyvsp[-6].ctype), STRcpy((yyvsp[-5].id)), NULL, (yyvsp[-1].node), NULL);
      }
#line 1572 "y.tab.c"
    break;

  case 13: /* fundef: EXTERN type ID BRACKET_L param BRACKET_R SEMICOLON  */
#line 133 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFundef((yyvsp[-5].ctype), STRcpy((yyvsp[-4].id)), NULL, NULL, (yyvsp[-2].node));
        FUNDEF_ISEXTERN((yyval.node)) = 1;
      }
#line 1581 "y.tab.c"
    break;

  case 14: /* fundef: EXTERN type ID BRACKET_L BRACKET_R SEMICOLON  */
#line 138 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFundef((yyvsp[-4].ctype), STRcpy((yyvsp[-3].id)), NULL, NULL, NULL);
        FUNDEF_ISEXTERN((yyval.node)) = 1;
      }
#line 1590 "y.tab.c"
    break;

  case 15: /* vardecl: type ID LET expr SEMICOLON vardecl  */
#line 145 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeVardecl(STRcpy((yyvsp[-4].id)), (yyvsp[-5].ctype), NULL, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1598 "y.tab.c"
    break;

  case 16: /* vardecl: type ID LET expr SEMICOLON  */
#line 149 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeVardecl(STRcpy((yyvsp[-3].id)), (yyvsp[-4].ctype), NULL, (yyvsp[-1].node), NULL);
      }
#line 1606 "y.tab.c"
    break;

  case 17: /* vardecl: type ID SEMICOLON  */
#line 153 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeVardecl(STRcpy((yyvsp[-1].id)), (yyvsp[-2].ctype), NULL, NULL, NULL);
      }
#line 1614 "y.tab.c"
    break;

  case 18: /* vardecl: type ID SEMICOLON vardecl  */
#line 157 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeVardecl(STRcpy((yyvsp[-2].id)), (yyvsp[-3].ctype), NULL, NULL, (yyvsp[0].node));
      }
#line 1622 "y.tab.c"
    break;

  case 19: /* funbody: vardecl stmts  */
#line 163 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFunbody((yyvsp[-1].node), NULL, (yyvsp[0].node));
      }
#line 1630 "y.tab.c"
    break;

  case 20: /* funbody: vardecl  */
#line 167 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFunbody((yyvsp[0].node), NULL, NULL);
      }
#line 1638 "y.tab.c"
    break;

  case 21: /* funbody: stmts  */
#line 171 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFunbody(NULL, NULL, (yyvsp[0].node));
      }
#line 1646 "y.tab.c"
    break;

  case 22: /* funbody: %empty  */
#line 175 "src/scanparse/civic.y"
      {
        (yyval.node) = NULL;
      }
#line 1654 "y.tab.c"
    break;

  case 23: /* param: type ID  */
#line 181 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeParam(STRcpy((yyvsp[0].id)), (yyvsp[-1].ctype), NULL, NULL);
      }
#line 1662 "y.tab.c"
    break;

  case 24: /* param: type ID COMMA param  */
#line 185 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeParam(STRcpy((yyvsp[-2].id)), (yyvsp[-3].ctype), NULL, (yyvsp[0].node));
      }
#line 1670 "y.tab.c"
    break;

  case 25: /* globdef: EXPORT type ID LET expr SEMICOLON  */
#line 191 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeGlobdef((yyvsp[-4].ctype), STRcpy((yyvsp[-3].id)), NULL, (yyvsp[-1].node));
        GLOBDEF_ISEXPORT((yyval.node)) = 1;
      }
#line 1679 "y.tab.c"
    break;

  case 26: /* globdef: EXPORT type ID SEMICOLON  */
#line 196 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeGlobdef((yyvsp[-2].ctype), STRcpy((yyvsp[-1].id)), NULL, NULL);
        GLOBDEF_ISEXPORT((yyval.node)) = 1;
      }
#line 1688 "y.tab.c"
    break;

  case 27: /* globdef: type ID LET expr SEMICOLON  */
#line 201 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeGlobdef((yyvsp[-4].ctype), STRcpy((yyvsp[-3].id)), NULL, (yyvsp[-1].node));
      }
#line 1696 "y.tab.c"
    break;

  case 28: /* globdef: type ID SEMICOLON  */
#line 205 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeGlobdef((yyvsp[-2].ctype), STRcpy((yyvsp[-1].id)), NULL, NULL);
      }
#line 1704 "y.tab.c"
    break;

  case 29: /* exprs: expr COMMA exprs  */
#line 211 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeExprs((yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1712 "y.tab.c"
    break;

  case 30: /* exprs: expr  */
#line 215 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeExprs((yyvsp[0].node), NULL);
      }
#line 1720 "y.tab.c"
    break;

  case 31: /* expr: constant  */
#line 221 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1728 "y.tab.c"
    break;

  case 32: /* expr: BRACKET_L expr BRACKET_R  */
#line 225 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[-1].node);
      }
#line 1736 "y.tab.c"
    break;

  case 33: /* expr: binop  */
#line 229 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1744 "y.tab.c"
    break;

  case 34: /* expr: monop  */
#line 233 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1752 "y.tab.c"
    break;

  case 35: /* expr: BRACKET_L type BRACKET_R expr  */
#line 237 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeCast((yyvsp[-2].ctype), (yyvsp[0].node));
      }
#line 1760 "y.tab.c"
    break;

  case 36: /* expr: funcall  */
#line 241 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1768 "y.tab.c"
    break;

  case 37: /* expr: ID  */
#line 245 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeVar(STRcpy((yyvsp[0].id)), NULL, NULL);
      }
#line 1776 "y.tab.c"
    break;

  case 38: /* binop: expr PLUS expr  */
#line 251 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_add, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1784 "y.tab.c"
    break;

  case 39: /* binop: expr MINUS expr  */
#line 255 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_sub, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1792 "y.tab.c"
    break;

  case 40: /* binop: expr STAR expr  */
#line 259 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_mul, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1800 "y.tab.c"
    break;

  case 41: /* binop: expr SLASH expr  */
#line 263 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_div, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1808 "y.tab.c"
    break;

  case 42: /* binop: expr PERCENT expr  */
#line 267 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_mod, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1816 "y.tab.c"
    break;

  case 43: /* binop: expr LE expr  */
#line 271 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_le, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1824 "y.tab.c"
    break;

  case 44: /* binop: expr LT expr  */
#line 275 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_lt, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1832 "y.tab.c"
    break;

  case 45: /* binop: expr GE expr  */
#line 279 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_ge, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1840 "y.tab.c"
    break;

  case 46: /* binop: expr GT expr  */
#line 283 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_gt, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1848 "y.tab.c"
    break;

  case 47: /* binop: expr EQ expr  */
#line 287 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_eq, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1856 "y.tab.c"
    break;

  case 48: /* binop: expr NE expr  */
#line 291 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_ne, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1864 "y.tab.c"
    break;

  case 49: /* binop: expr OR expr  */
#line 295 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_or, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1872 "y.tab.c"
    break;

  case 50: /* binop: expr AND expr  */
#line 299 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBinop( BO_and, (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 1880 "y.tab.c"
    break;

  case 51: /* monop: FACTORIAL expr  */
#line 305 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeMonop( MO_not, (yyvsp[0].node));
      }
#line 1888 "y.tab.c"
    break;

  case 52: /* monop: MINUS expr  */
#line 309 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeMonop( MO_neg, (yyvsp[0].node));
      }
#line 1896 "y.tab.c"
    break;

  case 53: /* funcall: ID BRACKET_L BRACKET_R  */
#line 315 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFuncall(STRcpy((yyvsp[-2].id)), NULL, NULL);
      }
#line 1904 "y.tab.c"
    break;

  case 54: /* funcall: ID BRACKET_L exprs BRACKET_R  */
#line 319 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFuncall(STRcpy((yyvsp[-3].id)), NULL, (yyvsp[-1].node));
      }
#line 1912 "y.tab.c"
    break;

  case 55: /* block: BRACES_L stmts BRACES_R  */
#line 325 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[-1].node);
      }
#line 1920 "y.tab.c"
    break;

  case 56: /* block: BRACES_L BRACES_R  */
#line 329 "src/scanparse/civic.y"
      {
        (yyval.node) = NULL;
      }
#line 1928 "y.tab.c"
    break;

  case 57: /* block: stmt  */
#line 333 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1936 "y.tab.c"
    break;

  case 58: /* stmts: stmt stmts  */
#line 339 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeStmts( (yyvsp[-1].node), (yyvsp[0].node));
      }
#line 1944 "y.tab.c"
    break;

  case 59: /* stmts: stmt  */
#line 343 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeStmts( (yyvsp[0].node), NULL);
      }
#line 1952 "y.tab.c"
    break;

  case 60: /* stmt: exprstmt  */
#line 349 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1960 "y.tab.c"
    break;

  case 61: /* stmt: assign  */
#line 353 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1968 "y.tab.c"
    break;

  case 62: /* stmt: ifelse  */
#line 357 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1976 "y.tab.c"
    break;

  case 63: /* stmt: while  */
#line 361 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1984 "y.tab.c"
    break;

  case 64: /* stmt: dowhile  */
#line 365 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 1992 "y.tab.c"
    break;

  case 65: /* stmt: for  */
#line 369 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 2000 "y.tab.c"
    break;

  case 66: /* stmt: return  */
#line 373 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 2008 "y.tab.c"
    break;

  case 67: /* exprstmt: expr SEMICOLON  */
#line 379 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeExprstmt((yyvsp[-1].node));
      }
#line 2016 "y.tab.c"
    break;

  case 68: /* assign: varlet LET expr SEMICOLON  */
#line 385 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeAssign((yyvsp[-3].node), (yyvsp[-1].node));
      }
#line 2024 "y.tab.c"
    break;

  case 69: /* ifelse: IF BRACKET_L expr BRACKET_R block ELSE block  */
#line 391 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeIfelse((yyvsp[-4].node), (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 2032 "y.tab.c"
    break;

  case 70: /* ifelse: IF BRACKET_L expr BRACKET_R block  */
#line 395 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeIfelse((yyvsp[-2].node), (yyvsp[0].node), NULL);
      }
#line 2040 "y.tab.c"
    break;

  case 71: /* while: WHILE BRACKET_L expr BRACKET_R block  */
#line 401 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeWhile((yyvsp[-2].node), (yyvsp[0].node));
      }
#line 2048 "y.tab.c"
    break;

  case 72: /* dowhile: DO block WHILE BRACKET_L expr BRACKET_R SEMICOLON  */
#line 407 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeDowhile((yyvsp[-2].node), (yyvsp[-5].node));
      }
#line 2056 "y.tab.c"
    break;

  case 73: /* for: FOR BRACKET_L TYPE_INT ID LET expr COMMA expr BRACKET_R block  */
#line 413 "src/scanparse/civic.y"
      {
        (yyval.node) =  TBmakeFor((yyvsp[-6].id), (yyvsp[-4].node), (yyvsp[-2].node), NULL, (yyvsp[0].node));
      }
#line 2064 "y.tab.c"
    break;

  case 74: /* for: FOR BRACKET_L TYPE_INT ID LET expr COMMA expr COMMA expr BRACKET_R block  */
#line 417 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFor((yyvsp[-8].id), (yyvsp[-6].node), (yyvsp[-4].node), (yyvsp[-2].node), (yyvsp[0].node));
      }
#line 2072 "y.tab.c"
    break;

  case 75: /* return: RETURN expr SEMICOLON  */
#line 423 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeReturn((yyvsp[-1].node));
      }
#line 2080 "y.tab.c"
    break;

  case 76: /* return: RETURN SEMICOLON  */
#line 427 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeReturn(NULL);
      }
#line 2088 "y.tab.c"
    break;

  case 77: /* varlet: ID  */
#line 433 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeVarlet(STRcpy((yyvsp[0].id)), NULL, NULL);     //Hoe moeten deze opgesteld worden wat zijn de decl en indices?
      }
#line 2096 "y.tab.c"
    break;

  case 78: /* floatval: FLOAT  */
#line 439 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeFloat( (yyvsp[0].cflt));
      }
#line 2104 "y.tab.c"
    break;

  case 79: /* intval: NUM  */
#line 445 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeNum( (yyvsp[0].cint));
      }
#line 2112 "y.tab.c"
    break;

  case 80: /* boolval: TRUEVAL  */
#line 451 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBool( TRUE);
      }
#line 2120 "y.tab.c"
    break;

  case 81: /* boolval: FALSEVAL  */
#line 455 "src/scanparse/civic.y"
      {
        (yyval.node) = TBmakeBool( FALSE);
      }
#line 2128 "y.tab.c"
    break;

  case 82: /* type: TYPE_BOOL  */
#line 461 "src/scanparse/civic.y"
      {
        (yyval.ctype) = T_bool;
      }
#line 2136 "y.tab.c"
    break;

  case 83: /* type: TYPE_INT  */
#line 465 "src/scanparse/civic.y"
      {
        (yyval.ctype) = T_int;
      }
#line 2144 "y.tab.c"
    break;

  case 84: /* type: TYPE_FLOAT  */
#line 469 "src/scanparse/civic.y"
      {
        (yyval.ctype) = T_float;
      }
#line 2152 "y.tab.c"
    break;

  case 85: /* type: TYPE_VOID  */
#line 473 "src/scanparse/civic.y"
      {
        (yyval.ctype) = T_void;
      }
#line 2160 "y.tab.c"
    break;

  case 86: /* constant: intval  */
#line 479 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 2168 "y.tab.c"
    break;

  case 87: /* constant: boolval  */
#line 483 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 2176 "y.tab.c"
    break;

  case 88: /* constant: floatval  */
#line 487 "src/scanparse/civic.y"
      {
        (yyval.node) = (yyvsp[0].node);
      }
#line 2184 "y.tab.c"
    break;


#line 2188 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 504 "src/scanparse/civic.y"

static int yyerror (char *error)
{
  CTIabort("line %d, col %d\nError parsing source code: %s\n",
            global.line, global.col, error);
  return( 0);
}

node *YYparseTree( void)
{
  yydebug = 0;
  DBUG_ENTER("YYparseTree");

  yyparse();

  DBUG_RETURN( parseresult);
}

