#ifndef _OPT_SUB_H_
#define _OPT_SUB_H_
#include "types.h"

extern node *OSbinop (node *arg_node, info *arg_info);
extern node *OSdoOptSub( node *syntaxtree);

#endif
