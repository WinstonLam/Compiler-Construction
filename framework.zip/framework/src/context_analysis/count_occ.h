#ifndef _COUNT_OCCURANCES_H_
#define _COUNT_OCCURANCES_H_

#include "types.h"

extern node *COvar (node *arg_node, info *arg_info);
extern node *COdoCountOcc( node *syntaxtree);

#endif
