#ifndef _BOOL_EVALUATION_H_
#define _BOOL_EVALUATION_H_
#include "types.h"

extern node *BEbinop (node *arg_node, info *arg_info);
extern node *BEdoBoolEvaluation( node *syntaxtree);

#endif
