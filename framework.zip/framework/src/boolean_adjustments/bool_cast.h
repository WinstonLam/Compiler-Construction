#ifndef _BOOL_CAST_H_
#define _BOOL_CAST_H_
#include "types.h"

extern node *BCcast (node *arg_node, info *arg_info);
extern node *BCdoBoolCast( node *syntaxtree);

#endif
